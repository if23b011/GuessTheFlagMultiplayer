Webbasiertes Multiplayer Minigame: Flaggen erraten
